// ── Movie Data ────────────────────────────────────────────────────────────
const MOVIES = [
  { id: 1, title: "Dune: Part Two",  genre: "Sci-Fi",      rating: 8.6, price: 280, duration: "166 min", lang: "English", emoji: "🏜️", color: "#C4A35A", desc: "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family." },
  { id: 2, title: "KGF Chapter 3",   genre: "Action",      rating: 9.1, price: 320, duration: "180 min", lang: "Hindi",   emoji: "⚒️", color: "#E85D04", desc: "Rocky's son continues the legacy of gold and blood in the mines of Kolar." },
  { id: 3, title: "Kalki 2898 AD",   genre: "Mythology",   rating: 8.4, price: 300, duration: "190 min", lang: "Telugu",  emoji: "🌌", color: "#7B2FBE", desc: "An epic saga set in a dystopian future where mythology meets science fiction." },
  { id: 4, title: "Fighter",         genre: "Action",      rating: 7.9, price: 260, duration: "166 min", lang: "Hindi",   emoji: "✈️", color: "#0077B6", desc: "Indian Air Force officers take on terrorists in this high-octane aerial action thriller." },
  { id: 5, title: "Pushpa 2",        genre: "Drama",       rating: 9.3, price: 350, duration: "210 min", lang: "Telugu",  emoji: "🌺", color: "#D62828", desc: "Pushpa Raj returns in the thrilling sequel with even higher stakes in the red sandalwood trade." },
  { id: 6, title: "Oppenheimer",     genre: "Biographical",rating: 8.9, price: 290, duration: "180 min", lang: "English", emoji: "☢️", color: "#F77F00", desc: "The story of J. Robert Oppenheimer and the development of the atomic bomb during WWII." },
];

const THEATERS = [
  { name: "PVR Cinemas - Orion Mall",  address: "Rajajinagar, Bengaluru 560010" },
  { name: "INOX - Garuda Mall",        address: "Magrath Road, Bengaluru 560025" },
  { name: "Cinepolis - Forum Mall",    address: "Koramangala, Bengaluru 560095" },
];

const TIMES = ["10:00 AM", "01:30 PM", "04:45 PM", "07:15 PM", "10:00 PM"];
const SEAT_ROWS = ["A","B","C","D","E","F","G","H"];
const OCCUPIED  = new Set(["A3","A7","B2","B5","C1","C4","C8","D3","D6","E2","E9","F4","F7","G1","G5","H3","H8"]);

// ── Render Movie Grid ─────────────────────────────────────────────────────
function renderMovies(filter = "") {
  const grid = document.getElementById("movies-grid");
  const count = document.getElementById("movie-count");
  if (!grid) return;

  const filtered = MOVIES.filter(m =>
    m.title.toLowerCase().includes(filter.toLowerCase()) ||
    m.genre.toLowerCase().includes(filter.toLowerCase())
  );

  if (count) count.textContent = filtered.length + " available";

  grid.innerHTML = filtered.map(m => `
    <a class="movie-card" href="/b1?movie=${encodeURIComponent(m.title)}&theater=&address=&price=${m.price}" onclick="setBookingMovie(${m.id}); return true;">
      <div class="movie-poster">
        <div class="movie-poster-overlay" style="background: radial-gradient(circle at 50% 50%, ${m.color}55, transparent);"></div>
        <div class="movie-poster-emoji">${m.emoji}</div>
      </div>
      <div class="movie-info">
        <span class="badge">${m.genre}</span>
        <div class="movie-title">${m.title}</div>
        <div class="movie-meta">
          <span class="rating">★ ${m.rating}</span>
          <span>·</span><span>${m.duration}</span>
          <span>·</span><span>${m.lang}</span>
        </div>
        <p class="movie-desc">${m.desc.slice(0, 85)}…</p>
        <div class="movie-footer">
          <div class="movie-price">₹${m.price} <small>onwards</small></div>
          <button class="btn btn-gold btn-sm">Book Now</button>
        </div>
      </div>
    </a>
  `).join("");
}

function setBookingMovie(id) {
  const m = MOVIES.find(x => x.id === id);
  if (m) sessionStorage.setItem("currentMovie", JSON.stringify(m));
}

// ── Booking Page Logic ────────────────────────────────────────────────────
let selectedTheater = null;
let selectedDate    = null;
let selectedTime    = null;
let selectedSeats   = [];

function initBookingPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const movieTitle = urlParams.get("movie");
  const moviePrice = parseInt(urlParams.get("price") || "0");

  // Restore movie from sessionStorage if available
  let movie = null;
  try { movie = JSON.parse(sessionStorage.getItem("currentMovie")); } catch(e) {}
  if (!movie && movieTitle) movie = MOVIES.find(m => m.title === movieTitle);

  if (movie) {
    document.getElementById("booking-movie-emoji").textContent  = movie.emoji;
    document.getElementById("booking-movie-icon").style.background = `${movie.color}22`;
    document.getElementById("booking-movie-title").textContent = movie.title;
    document.getElementById("booking-movie-meta").textContent  = `★ ${movie.rating} · ${movie.genre} · ${movie.duration} · ${movie.lang}`;
    document.getElementById("summary-movie").textContent       = movie.title;
    document.getElementById("price-per-seat").textContent      = `₹${movie.price}`;
    document.getElementById("hidden-price").value              = movie.price;
    document.getElementById("hidden-movie").value              = movie.title;
  }

  renderTheaters();
  renderDates();
  renderTimes();
  renderSeatMap(parseInt(document.getElementById("hidden-price")?.value || "0"));
}

function renderTheaters() {
  const el = document.getElementById("theater-list");
  if (!el) return;
  el.innerHTML = THEATERS.map((t, i) => `
    <div class="theater-item" id="theater-${i}" onclick="selectTheater(${i})">
      <div class="theater-name">${t.name}</div>
      <div class="theater-addr">📍 ${t.address}</div>
    </div>
  `).join("");
}

function selectTheater(idx) {
  selectedTheater = THEATERS[idx];
  document.querySelectorAll(".theater-item").forEach(el => el.classList.remove("active"));
  document.getElementById(`theater-${idx}`).classList.add("active");
  document.getElementById("summary-theater").textContent = selectedTheater.name;
  document.getElementById("hidden-theater").value  = selectedTheater.name;
  document.getElementById("hidden-address").value  = selectedTheater.address;
  updateTotal();
}

function renderDates() {
  const el = document.getElementById("date-grid");
  if (!el) return;
  const days  = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const today = new Date();
  let html = "";
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const label = i === 0 ? "Today" : days[d.getDay()];
    const full  = `${String(d.getDate()).padStart(2,"0")} ${months[d.getMonth()]} ${d.getFullYear()}`;
    html += `
      <button class="date-btn" id="date-${i}" onclick="selectDate(${i}, '${full}')">
        <span class="day">${label}</span>
        <span class="num">${d.getDate()}</span>
        <span class="mon">${months[d.getMonth()]}</span>
      </button>`;
  }
  el.innerHTML = html;
}

function selectDate(idx, full) {
  selectedDate = full;
  document.querySelectorAll(".date-btn").forEach(el => el.classList.remove("active"));
  document.getElementById(`date-${idx}`).classList.add("active");
  document.getElementById("summary-date").textContent  = full;
  document.getElementById("hidden-date").value         = full;
  updateTotal();
}

function renderTimes() {
  const el = document.getElementById("times-grid");
  if (!el) return;
  el.innerHTML = TIMES.map((t, i) => `
    <button class="time-btn" id="time-${i}" onclick="selectTime(${i}, '${t}')">${t}</button>
  `).join("");
}

function selectTime(idx, t) {
  selectedTime = t;
  document.querySelectorAll(".time-btn").forEach(el => el.classList.remove("active"));
  document.getElementById(`time-${idx}`).classList.add("active");
  document.getElementById("summary-time").textContent = t;
  document.getElementById("hidden-time").value        = t;
  updateTotal();
}

function renderSeatMap(pricePerSeat) {
  const el = document.getElementById("seat-map");
  if (!el) return;
  let html = "";
  SEAT_ROWS.forEach(row => {
    html += `<div class="seat-row"><div class="row-label">${row}</div><div class="seats">`;
    for (let i = 1; i <= 10; i++) {
      if (i === 6) html += `<div class="seat-gap"></div>`;
      const sid = `${row}${i}`;
      const occ = OCCUPIED.has(sid) ? "occupied" : "";
      html += `<div class="seat ${occ}" id="seat-${sid}" onclick="toggleSeat('${sid}', ${pricePerSeat})">${i}</div>`;
    }
    html += `</div></div>`;
  });
  el.innerHTML = html;
}

function toggleSeat(sid, pricePerSeat) {
  if (OCCUPIED.has(sid)) return;
  const el = document.getElementById(`seat-${sid}`);
  if (el.classList.contains("selected")) {
    el.classList.remove("selected");
    selectedSeats = selectedSeats.filter(s => s !== sid);
  } else {
    el.classList.add("selected");
    selectedSeats.push(sid);
  }
  document.getElementById("summary-seats").textContent = selectedSeats.length > 0 ? selectedSeats.join(", ") : "—";
  document.getElementById("hidden-seats").value = selectedSeats.join(", ");
  updateTotal();
}

function updateTotal() {
  const price = parseInt(document.getElementById("hidden-price")?.value || "0");
  const total = selectedSeats.length * price;
  document.getElementById("summary-total").textContent   = `₹${total}`;
  document.getElementById("pay-btn").textContent         = `Pay ₹${total} & Book`;
  document.getElementById("hidden-amount").value         = total;
}

function submitBooking() {
  if (!selectedTheater) { showError("Please select a theater."); return; }
  if (!selectedDate)    { showError("Please select a date."); return; }
  if (!selectedTime)    { showError("Please select a showtime."); return; }
  if (selectedSeats.length === 0) { showError("Please select at least one seat."); return; }
  hideError();
  document.getElementById("pay-btn").innerHTML = '<span style="display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 0.7s linear infinite;"></span> Processing…';
  document.getElementById("booking-form").submit();
}

function showError(msg) {
  const el = document.getElementById("booking-error");
  if (el) { el.textContent = "⚠️ " + msg; el.style.display = "flex"; }
}
function hideError() {
  const el = document.getElementById("booking-error");
  if (el) el.style.display = "none";
}

// ── Search ────────────────────────────────────────────────────────────────
function initSearch() {
  const inp = document.getElementById("movie-search");
  if (inp) inp.addEventListener("input", e => renderMovies(e.target.value));
}

// ── Init ──────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("movies-grid")) {
    renderMovies();
    initSearch();
  }
  if (document.getElementById("booking-form")) {
    initBookingPage();
  }
});
